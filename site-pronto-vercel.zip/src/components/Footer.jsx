
import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Leaf, Mail, Phone, Instagram, MapPin } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-[#1a4d3a]/90 backdrop-blur-sm border-t border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Logo & Description */}
          <div className="space-y-4">
            <div className="flex items-center space-x-3">
              <Leaf className="h-8 w-8 text-[#d4af37]" />
              <div>
                <span className="font-display text-xl font-bold text-[#f5f3f0]">
                  Antiqua Silvanus
                </span>
                <p className="text-xs text-[#7a9471]">Eco Lodge Madeira</p>
              </div>
            </div>
            <p className="text-[#7a9471] text-sm leading-relaxed">
              Experiência única na floresta Laurissilva da Madeira, onde o turismo sustentável encontra o bem-estar e a natureza.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <span className="font-display text-lg font-semibold text-[#f5f3f0] mb-4 block">
              Links Rápidos
            </span>
            <div className="space-y-2">
              {[
                { path: '/alojamentos', label: 'Alojamentos' },
                { path: '/atividades', label: 'Atividades' },
                { path: '/workshops', label: 'Workshops' },
                { path: '/restaurante', label: 'Restaurante' }
              ].map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  className="block text-[#7a9471] hover:text-[#d4af37] transition-colors duration-300 text-sm"
                >
                  {item.label}
                </Link>
              ))}
            </div>
          </div>

          {/* Contact Info */}
          <div>
            <span className="font-display text-lg font-semibold text-[#f5f3f0] mb-4 block">
              Contactos
            </span>
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <Mail className="h-4 w-4 text-[#d4af37]" />
                <span className="text-[#7a9471] text-sm">info@antiquasilvanus.pt</span>
              </div>
              <div className="flex items-center space-x-3">
                <Phone className="h-4 w-4 text-[#d4af37]" />
                <span className="text-[#7a9471] text-sm">+351 912 345 678</span>
              </div>
              <div className="flex items-center space-x-3">
                <Instagram className="h-4 w-4 text-[#d4af37]" />
                <span className="text-[#7a9471] text-sm">@antiquasilvanus</span>
              </div>
            </div>
          </div>

          {/* Location */}
          <div>
            <span className="font-display text-lg font-semibold text-[#f5f3f0] mb-4 block">
              Localização
            </span>
            <div className="flex items-start space-x-3">
              <MapPin className="h-4 w-4 text-[#d4af37] mt-1 flex-shrink-0" />
              <span className="text-[#7a9471] text-sm leading-relaxed">
                Vereda da Floresta 42<br />
                Porto Moniz, Madeira
              </span>
            </div>
          </div>
        </div>

        <div className="border-t border-white/10 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <p className="text-[#7a9471] text-sm">
              © {currentYear} Antiqua Silvanus. Todos os direitos reservados.
            </p>
            <div className="flex space-x-6">
              <span className="text-[#7a9471] text-sm hover:text-[#d4af37] transition-colors duration-300 cursor-pointer">
                Política de Privacidade
              </span>
              <span className="text-[#7a9471] text-sm hover:text-[#d4af37] transition-colors duration-300 cursor-pointer">
                Termos de Serviço
              </span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
