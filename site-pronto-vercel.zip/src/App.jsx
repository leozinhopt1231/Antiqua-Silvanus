
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Toaster } from '@/components/ui/toaster';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import Home from '@/pages/Home';
import Accommodations from '@/pages/Accommodations';
import Activities from '@/pages/Activities';
import Workshops from '@/pages/Workshops';
import Restaurant from '@/pages/Restaurant';
import TouristSpots from '@/pages/TouristSpots';
import Inauguration from '@/pages/Inauguration';
import Contact from '@/pages/Contact';

function App() {
  return (
    <Router>
      <div className="min-h-screen nature-gradient leaf-pattern">
        <Navbar />
        <main>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/alojamentos" element={<Accommodations />} />
            <Route path="/atividades" element={<Activities />} />
            <Route path="/workshops" element={<Workshops />} />
            <Route path="/restaurante" element={<Restaurant />} />
            <Route path="/pontos-turisticos" element={<TouristSpots />} />
            <Route path="/inauguracao" element={<Inauguration />} />
            <Route path="/contactos" element={<Contact />} />
          </Routes>
        </main>
        <Footer />
        <Toaster />
      </div>
    </Router>
  );
}

export default App;
