import React from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { MapPin, Camera, Mountain, Eye, Car, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';

const TouristSpots = () => {
  const touristSpots = [
    {
      id: 1,
      name: "Fanal",
      description: "Floresta mística com árvores centenárias envolvidas em neblina, criando paisagens de sonho únicas na Madeira.",
      distance: "15 min",
      highlights: [
        "Árvores centenárias",
        "Paisagens místicas",
        "Fotografia única",
        "Trilhos pedestres",
        "Flora endémica"
      ],
      type: "Floresta",
      image: "Mystical Fanal forest with ancient trees covered in mist creating dreamlike landscapes"
    },
    {
      id: 2,
      name: "Paul da Serra",
      description: "Planalto único na Madeira com paisagens lunares, ideal para caminhadas e observação da natureza selvagem.",
      distance: "20 min",
      highlights: [
        "Planalto único",
        "Paisagens lunares",
        "Caminhadas livres",
        "Natureza selvagem",
        "Vistas panorâmicas"
      ],
      type: "Planalto",
      image: "Paul da Serra plateau with lunar-like landscapes and wild nature in Madeira"
    },
    {
      id: 3,
      name: "Porto Moniz",
      description: "Piscinas naturais vulcânicas junto ao oceano Atlântico, oferecendo uma experiência de banho única.",
      distance: "25 min",
      highlights: [
        "Piscinas naturais",
        "Origem vulcânica",
        "Banhos oceânicos",
        "Restaurantes locais",
        "Centro de visitantes"
      ],
      type: "Costa",
      image: "Natural volcanic pools in Porto Moniz with Atlantic Ocean waves and unique swimming experience"
    },
    {
      id: 4,
      name: "Seixal",
      description: "Praia de areia preta vulcânica com cascatas espetaculares e paisagens dramáticas da costa norte.",
      distance: "30 min",
      highlights: [
        "Praia de areia preta",
        "Cascatas naturais",
        "Costa dramática",
        "Trilhos costeiros",
        "Miradouros únicos"
      ],
      type: "Praia",
      image: "Seixal black sand beach with spectacular waterfalls and dramatic northern coastline"
    }
  ];

  const activities = [
    {
      name: "Trilhos Pedestres",
      description: "Rede extensa de trilhos pela floresta Laurissilva",
      icon: <Mountain className="h-6 w-6" />
    },
    {
      name: "Miradouros",
      description: "Pontos de vista únicos sobre a paisagem madeirense",
      icon: <Eye className="h-6 w-6" />
    },
    {
      name: "Fotografia",
      description: "Locais perfeitos para capturar a beleza natural",
      icon: <Camera className="h-6 w-6" />
    }
  ];

  const handleGetDirections = (spotName) => {
    toast({
      title: "🗺️ Direções Solicitadas!",
      description: `🚧 A funcionalidade de direções para ${spotName} ainda não está implementada—mas não se preocupe! Pode solicitar esta funcionalidade no seu próximo prompt! 🚀`,
      duration: 5000,
    });
  };

  return (
    <>
      <Helmet>
        <title>Pontos Turísticos Próximos - Antiqua Silvanus Eco Lodge</title>
        <meta name="description" content="Descubra os pontos turísticos próximos: Fanal, Paul da Serra, Porto Moniz e Seixal. Trilhos, miradouros e paisagens únicas da floresta Laurissilva." />
      </Helmet>

      {/* Hero Section */}
      <section className="relative min-h-[60vh] flex items-center justify-center overflow-hidden mt-20">
        <div className="absolute inset-0 z-0">
          <img  alt="Paisagens deslumbrantes dos pontos turísticos próximos da Madeira" className="w-full h-full object-cover" src="https://images.unsplash.com/photo-1612940062558-6b7570374348" />
          <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/30 to-black/60"></div>
        </div>

        <div className="relative z-10 text-center px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1 }}
            className="space-y-6"
          >
            <h1 className="font-display text-5xl md:text-6xl font-bold text-[#f5f3f0] text-shadow">
              Pontos <span className="text-[#d4af37]">Turísticos</span>
            </h1>
            <p className="text-xl md:text-2xl text-[#7a9471] max-w-3xl mx-auto">
              Descubra as maravilhas naturais próximas do nosso eco lodge
            </p>
          </motion.div>
        </div>
      </section>

      {/* Tourist Spots Grid */}
      <section className="section-padding">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="font-display text-4xl md:text-5xl font-bold text-[#f5f3f0] mb-6">
              Destinos <span className="text-[#d4af37]">Próximos</span>
            </h2>
            <p className="text-xl text-[#7a9471] max-w-3xl mx-auto">
              Explore os locais mais emblemáticos da Madeira, todos a poucos minutos do nosso lodge
            </p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {touristSpots.map((spot, index) => (
              <motion.div
                key={spot.id}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="glass-effect rounded-2xl overflow-hidden hover-lift group"
              >
                <div className="relative h-64">
                  <img  alt={spot.description} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" src="https://images.unsplash.com/photo-1590342986688-0d28777219cf" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                  
                  <div className="absolute top-4 left-4 bg-[#d4af37]/90 rounded-full px-4 py-2">
                    <span className="text-[#1a4d3a] font-semibold text-sm">{spot.type}</span>
                  </div>
                  
                  <div className="absolute bottom-4 right-4 glass-effect rounded-xl p-3">
                    <div className="flex items-center space-x-2 text-[#f5f3f0]">
                      <Car className="h-4 w-4" />
                      <span className="text-sm font-medium">{spot.distance}</span>
                    </div>
                  </div>
                </div>

                <div className="p-8 space-y-6">
                  <div>
                    <h3 className="font-display text-2xl font-bold text-[#f5f3f0] mb-3">
                      {spot.name}
                    </h3>
                    <p className="text-[#7a9471] leading-relaxed">
                      {spot.description}
                    </p>
                  </div>

                  <div className="space-y-3">
                    <h4 className="font-semibold text-[#f5f3f0]">Destaques:</h4>
                    <div className="grid grid-cols-1 gap-2">
                      {spot.highlights.map((highlight, highlightIndex) => (
                        <div key={highlightIndex} className="flex items-center space-x-2">
                          <div className="w-2 h-2 bg-[#d4af37] rounded-full"></div>
                          <span className="text-[#7a9471] text-sm">{highlight}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="pt-4">
                    <Button 
                      onClick={() => handleGetDirections(spot.name)}
                      className="w-full bg-[#d4af37] hover:bg-[#d4af37]/90 text-[#1a4d3a] font-semibold py-3 rounded-full"
                    >
                      Como Chegar
                    </Button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Activities Section */}
      <section className="section-padding bg-black/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="font-display text-4xl md:text-5xl font-bold text-[#f5f3f0] mb-6">
              Atividades <span className="text-[#d4af37]">Disponíveis</span>
            </h2>
            <p className="text-xl text-[#7a9471] max-w-3xl mx-auto">
              Aproveite ao máximo a sua visita com estas atividades únicas
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {activities.map((activity, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.2 }}
                viewport={{ once: true }}
                className="glass-effect rounded-2xl p-8 text-center hover-lift"
              >
                <div className="inline-flex items-center justify-center w-16 h-16 bg-[#d4af37]/20 rounded-full mb-6">
                  <div className="text-[#d4af37]">
                    {activity.icon}
                  </div>
                </div>
                <h3 className="font-display text-2xl font-semibold text-[#f5f3f0] mb-4">
                  {activity.name}
                </h3>
                <p className="text-[#7a9471] leading-relaxed">
                  {activity.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Map Section */}
      <section className="section-padding">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <h2 className="font-display text-4xl md:text-5xl font-bold text-[#f5f3f0] mb-6">
                Localização <span className="text-[#d4af37]">Privilegiada</span>
              </h2>
              <div className="space-y-6 text-[#7a9471] text-lg leading-relaxed">
                <p>
                  O Antiqua Silvanus está estrategicamente localizado no coração 
                  da floresta Laurissilva, oferecendo acesso fácil aos principais 
                  pontos turísticos da região norte da Madeira.
                </p>
                <p>
                  Todos os destinos estão a poucos minutos de distância, permitindo 
                  que explore as maravilhas naturais da ilha sem longas viagens, 
                  maximizando o seu tempo de descoberta.
                </p>
                <p>
                  A nossa equipa está sempre disponível para fornecer direções, 
                  sugestões de itinerários e informações sobre os melhores horários 
                  para visitar cada local.
                </p>
              </div>

              <div className="mt-8 grid grid-cols-2 gap-4">
                <div className="glass-effect rounded-xl p-4 text-center">
                  <MapPin className="h-6 w-6 text-[#d4af37] mx-auto mb-2" />
                  <div className="text-[#f5f3f0] font-semibold text-sm">4 Destinos</div>
                  <div className="text-[#7a9471] text-xs">Principais</div>
                </div>
                <div className="glass-effect rounded-xl p-4 text-center">
                  <Clock className="h-6 w-6 text-[#d4af37] mx-auto mb-2" />
                  <div className="text-[#f5f3f0] font-semibold text-sm">15-30 min</div>
                  <div className="text-[#7a9471] text-xs">Distância máxima</div>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="relative"
            >
              <div className="relative rounded-2xl overflow-hidden hover-lift">
                <img  alt="Mapa da região mostrando a localização dos pontos turísticos" className="w-full h-96 object-cover" src="https://images.unsplash.com/photo-1632178151697-fd971baa906f" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent"></div>
                
                <div className="absolute bottom-6 left-6 glass-effect rounded-xl p-4">
                  <div className="text-[#f5f3f0] font-semibold">Antiqua Silvanus</div>
                  <div className="text-[#7a9471] text-sm">Ponto de partida ideal</div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section-padding bg-black/20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="glass-effect rounded-3xl p-12 hover-lift"
          >
            <h2 className="font-display text-4xl md:text-5xl font-bold text-[#f5f3f0] mb-6">
              Planeie a Sua <span className="text-[#d4af37]">Aventura</span>
            </h2>
            <p className="text-xl text-[#7a9471] mb-8 max-w-2xl mx-auto">
              A nossa equipa está pronta para ajudar a planear o seu itinerário 
              perfeito pelos pontos turísticos mais emblemáticos da Madeira.
            </p>
            
            <Button 
              onClick={() => handleGetDirections("todos os pontos turísticos")}
              className="bg-[#d4af37] hover:bg-[#d4af37]/90 text-[#1a4d3a] font-semibold px-8 py-4 text-lg rounded-full hover-lift"
            >
              Solicitar Itinerário
            </Button>
          </motion.div>
        </div>
      </section>
    </>
  );
};

export default TouristSpots;