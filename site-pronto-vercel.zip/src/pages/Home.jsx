import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { ArrowRight, Leaf, Mountain, Heart, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Home = () => {
  const features = [
    {
      icon: <Leaf className="h-8 w-8" />,
      title: "Turismo Sustentável",
      description: "Experiência ecológica respeitosa com a natureza"
    },
    {
      icon: <Mountain className="h-8 w-8" />,
      title: "Floresta Laurissilva",
      description: "Integrado na floresta património da UNESCO"
    },
    {
      icon: <Heart className="h-8 w-8" />,
      title: "Bem-estar",
      description: "Foco no relaxamento e conexão com a natureza"
    }
  ];

  return (
    <>
      <Helmet>
        <title>Antiqua Silvanus - Eco Lodge na Floresta Laurissilva da Madeira</title>
        <meta name="description" content="Eco Lodge na Madeira integrado na floresta Laurissilva, com foco em turismo sustentável, bem-estar e natureza. Alojamentos únicos, atividades e experiências autênticas." />
      </Helmet>

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img  alt="Floresta Laurissilva da Madeira com neblina matinal" className="w-full h-full object-cover" src="https://images.unsplash.com/photo-1508168208038-e16dcb2eb40e" />
          <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/20 to-black/60"></div>
        </div>

        <div className="relative z-10 text-center px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, ease: "easeOut" }}
            className="space-y-8"
          >
            <div className="space-y-4">
              <motion.h1 
                className="font-display text-5xl md:text-7xl lg:text-8xl font-bold text-[#f5f3f0] text-shadow leading-tight"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 1.2, delay: 0.2 }}
              >
                Antiqua
                <span className="block text-[#d4af37] animate-pulse-slow">Silvanus</span>
              </motion.h1>
              
              <motion.p 
                className="text-xl md:text-2xl text-[#7a9471] font-medium"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 1, delay: 0.5 }}
              >
                Eco Lodge na Floresta Laurissilva da Madeira
              </motion.p>
            </div>

            <motion.p 
              className="text-lg md:text-xl text-[#f5f3f0]/90 max-w-3xl mx-auto leading-relaxed"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1, delay: 0.7 }}
            >
              Uma experiência única onde o turismo sustentável encontra o bem-estar e a natureza. 
              Descubra a magia da floresta património da UNESCO num ambiente de puro relaxamento.
            </motion.p>

            <motion.div 
              className="flex flex-col sm:flex-row gap-4 justify-center items-center"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1, delay: 0.9 }}
            >
              <Link to="/alojamentos">
                <Button className="bg-[#d4af37] hover:bg-[#d4af37]/90 text-[#1a4d3a] font-semibold px-8 py-4 text-lg rounded-full hover-lift">
                  Descobrir Alojamentos
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              
              <Link to="/atividades">
                <Button variant="outline" className="border-[#f5f3f0] text-[#f5f3f0] hover:bg-[#f5f3f0] hover:text-[#1a4d3a] px-8 py-4 text-lg rounded-full hover-lift">
                  Ver Atividades
                </Button>
              </Link>
            </motion.div>
          </motion.div>
        </div>

        <motion.div 
          className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <div className="w-6 h-10 border-2 border-[#f5f3f0]/50 rounded-full flex justify-center">
            <div className="w-1 h-3 bg-[#f5f3f0]/50 rounded-full mt-2 animate-pulse"></div>
          </div>
        </motion.div>
      </section>

      {/* Features Section */}
      <section className="section-padding">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="font-display text-4xl md:text-5xl font-bold text-[#f5f3f0] mb-6">
              Uma Experiência <span className="text-[#d4af37]">Única</span>
            </h2>
            <p className="text-xl text-[#7a9471] max-w-3xl mx-auto">
              Mergulhe numa experiência autêntica onde cada detalhe foi pensado para proporcionar 
              momentos inesquecíveis em harmonia com a natureza.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.2 }}
                viewport={{ once: true }}
                className="glass-effect rounded-2xl p-8 text-center hover-lift group"
              >
                <div className="inline-flex items-center justify-center w-16 h-16 bg-[#d4af37]/20 rounded-full mb-6 group-hover:bg-[#d4af37]/30 transition-colors duration-300">
                  <div className="text-[#d4af37]">
                    {feature.icon}
                  </div>
                </div>
                <h3 className="font-display text-2xl font-semibold text-[#f5f3f0] mb-4">
                  {feature.title}
                </h3>
                <p className="text-[#7a9471] leading-relaxed">
                  {feature.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="section-padding bg-black/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <h2 className="font-display text-4xl md:text-5xl font-bold text-[#f5f3f0] mb-6">
                O Nosso <span className="text-[#d4af37]">Projeto</span>
              </h2>
              <div className="space-y-6 text-[#7a9471] text-lg leading-relaxed">
                <p>
                  O Antiqua Silvanus nasce da paixão pela natureza e pelo turismo sustentável. 
                  Localizado no coração da floresta Laurissilva da Madeira, oferecemos uma 
                  experiência única que combina conforto moderno com respeito pelo ambiente.
                </p>
                <p>
                  Os nossos alojamentos foram cuidadosamente integrados na paisagem natural, 
                  proporcionando aos nossos hóspedes uma conexão autêntica com a floresta 
                  património da UNESCO, sem comprometer o seu bem-estar.
                </p>
                <p>
                  Cada experiência é pensada para promover o relaxamento, a descoberta e 
                  a valorização da rica biodiversidade e cultura madeirense.
                </p>
              </div>
              
              <div className="mt-8">
                <Link to="/contactos">
                  <Button className="bg-[#d4af37] hover:bg-[#d4af37]/90 text-[#1a4d3a] font-semibold px-8 py-4 rounded-full hover-lift">
                    Saber Mais
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </Link>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="relative"
            >
              <div className="relative rounded-2xl overflow-hidden hover-lift">
                <img  alt="Eco lodge integrado na floresta com design sustentável" className="w-full h-96 object-cover" src="https://images.unsplash.com/photo-1703631092767-926061620be7" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent"></div>
              </div>
              
              <div className="absolute -bottom-6 -right-6 glass-effect rounded-xl p-6 max-w-xs">
                <div className="flex items-center space-x-2 mb-2">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-4 w-4 text-[#d4af37] fill-current" />
                  ))}
                </div>
                <p className="text-[#f5f3f0] font-semibold">Experiência Única</p>
                <p className="text-[#7a9471] text-sm">Na Floresta Laurissilva</p>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section-padding">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="glass-effect rounded-3xl p-12 hover-lift"
          >
            <h2 className="font-display text-4xl md:text-5xl font-bold text-[#f5f3f0] mb-6">
              Pronto para a <span className="text-[#d4af37]">Aventura?</span>
            </h2>
            <p className="text-xl text-[#7a9471] mb-8 max-w-2xl mx-auto">
              Descubra os nossos alojamentos únicos, atividades emocionantes e experiências 
              autênticas na floresta Laurissilva da Madeira.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/alojamentos">
                <Button className="bg-[#d4af37] hover:bg-[#d4af37]/90 text-[#1a4d3a] font-semibold px-8 py-4 text-lg rounded-full hover-lift">
                  Reservar Agora
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              
              <Link to="/inauguracao">
                <Button variant="outline" className="border-[#f5f3f0] text-[#f5f3f0] hover:bg-[#f5f3f0] hover:text-[#1a4d3a] px-8 py-4 text-lg rounded-full hover-lift">
                  Evento de Inauguração
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>
    </>
  );
};

export default Home;