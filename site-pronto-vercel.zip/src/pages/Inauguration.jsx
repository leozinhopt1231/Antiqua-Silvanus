import React from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { Calendar, Clock, Users, Music, Utensils, Sun, Heart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';

const Inauguration = () => {
  const eventSchedule = [
    {
      time: "06:00",
      activity: "Trilho ao Nascer do Sol",
      description: "Caminhada guiada pela floresta para assistir ao nascer do sol num local único",
      icon: <Sun className="h-6 w-6" />
    },
    {
      time: "08:30",
      activity: "Pequeno-almoço Comunitário",
      description: "Pequeno-almoço tradicional madeirense com produtos locais",
      icon: <Utensils className="h-6 w-6" />
    },
    {
      time: "10:00",
      activity: "Música ao Vivo",
      description: "Apresentações de artistas locais com música tradicional madeirense",
      icon: <Music className="h-6 w-6" />
    },
    {
      time: "11:30",
      activity: "Workshops Tradicionais",
      description: "Demonstrações de cestaria, pão tradicional e cosmética natural",
      icon: <Users className="h-6 w-6" />
    },
    {
      time: "14:00",
      activity: "Almoço Comunitário",
      description: "Refeição partilhada com especialidades regionais",
      icon: <Utensils className="h-6 w-6" />
    },
    {
      time: "16:00",
      activity: "Atividades Familiares",
      description: "Jogos tradicionais e atividades para toda a família",
      icon: <Heart className="h-6 w-6" />
    },
    {
      time: "19:00",
      activity: "Jantar Comunitário",
      description: "Grande jantar de celebração com a comunidade local",
      icon: <Utensils className="h-6 w-6" />
    },
    {
      time: "21:00",
      activity: "Espetáculo Cultural",
      description: "Apresentação de folclore madeirense e celebração final",
      icon: <Music className="h-6 w-6" />
    }
  ];

  const highlights = [
    {
      title: "Trilho ao Nascer do Sol",
      description: "Experiência única de caminhada matinal pela floresta Laurissilva",
      image: "Sunrise hiking trail through Laurissilva forest with golden morning light"
    },
    {
      title: "Música Tradicional",
      description: "Artistas locais apresentam o melhor da música madeirense",
      image: "Traditional Madeiran musicians performing folk music in natural forest setting"
    },
    {
      title: "Workshops Autênticos",
      description: "Demonstrações de artes e ofícios tradicionais da Madeira",
      image: "Traditional craft workshops with local artisans demonstrating authentic techniques"
    },
    {
      title: "Jantar Comunitário",
      description: "Celebração gastronómica com a participação da comunidade local",
      image: "Community dinner celebration with local people and traditional Madeiran food"
    }
  ];

  const handleRegistration = () => {
    toast({
      title: "🎉 Interesse Registado!",
      description: "🚧 A funcionalidade de inscrição para o evento de inauguração ainda não está implementada—mas não se preocupe! Pode solicitar esta funcionalidade no seu próximo prompt! 🚀",
      duration: 5000,
    });
  };

  return (
    <>
      <Helmet>
        <title>Evento de Inauguração - Antiqua Silvanus Eco Lodge</title>
        <meta name="description" content="Celebração de inauguração com trilho ao nascer do sol, música ao vivo, workshops tradicionais, jantar comunitário e envolvimento da população local." />
      </Helmet>

      {/* Hero Section */}
      <section className="relative min-h-[60vh] flex items-center justify-center overflow-hidden mt-20">
        <div className="absolute inset-0 z-0">
          <img  alt="Celebração de inauguração na floresta com comunidade local" className="w-full h-full object-cover" src="https://images.unsplash.com/photo-1558826312-6c2c59529f04" />
          <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/30 to-black/60"></div>
        </div>

        <div className="relative z-10 text-center px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1 }}
            className="space-y-6"
          >
            <h1 className="font-display text-5xl md:text-6xl font-bold text-[#f5f3f0] text-shadow">
              Evento de <span className="text-[#d4af37]">Inauguração</span>
            </h1>
            <p className="text-xl md:text-2xl text-[#7a9471] max-w-3xl mx-auto">
              Celebre connosco o início desta jornada única na floresta Laurissilva
            </p>
          </motion.div>
        </div>
      </section>

      {/* Event Info */}
      <section className="section-padding">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <h2 className="font-display text-4xl md:text-5xl font-bold text-[#f5f3f0] mb-6">
                Uma Celebração <span className="text-[#d4af37]">Especial</span>
              </h2>
              <div className="space-y-6 text-[#7a9471] text-lg leading-relaxed">
                <p>
                  O evento de inauguração do Antiqua Silvanus será uma celebração 
                  única que marca o início da nossa jornada no turismo sustentável 
                  da Madeira, com a participação ativa da comunidade local.
                </p>
                <p>
                  Desde o trilho ao nascer do sol até ao espetáculo cultural noturno, 
                  cada momento foi pensado para criar memórias inesquecíveis e 
                  fortalecer os laços com a nossa comunidade.
                </p>
                <p>
                  Esta celebração representa os nossos valores de sustentabilidade, 
                  autenticidade e respeito pela cultura e natureza madeirenses.
                </p>
              </div>

              <div className="mt-8 grid grid-cols-2 gap-6">
                <div className="glass-effect rounded-xl p-4 text-center">
                  <Calendar className="h-8 w-8 text-[#d4af37] mx-auto mb-2" />
                  <div className="text-[#f5f3f0] font-semibold">Data</div>
                  <div className="text-[#7a9471] text-sm">Em breve</div>
                </div>
                <div className="glass-effect rounded-xl p-4 text-center">
                  <Users className="h-8 w-8 text-[#d4af37] mx-auto mb-2" />
                  <div className="text-[#f5f3f0] font-semibold">Participação</div>
                  <div className="text-[#7a9471] text-sm">Gratuita</div>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="relative"
            >
              <div className="relative rounded-2xl overflow-hidden hover-lift">
                <img  alt="Preparativos para o evento de inauguração na floresta" className="w-full h-96 object-cover" src="https://images.unsplash.com/photo-1695661380706-23c36d44fb2c" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent"></div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Schedule */}
      <section className="section-padding bg-black/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="font-display text-4xl md:text-5xl font-bold text-[#f5f3f0] mb-6">
              Programa do <span className="text-[#d4af37]">Evento</span>
            </h2>
            <p className="text-xl text-[#7a9471] max-w-3xl mx-auto">
              Um dia completo de atividades, desde o nascer do sol até à celebração noturna
            </p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {eventSchedule.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="glass-effect rounded-2xl p-6 hover-lift"
              >
                <div className="flex items-start space-x-4">
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 bg-[#d4af37]/20 rounded-full flex items-center justify-center">
                      <div className="text-[#d4af37]">
                        {item.icon}
                      </div>
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <span className="bg-[#d4af37] text-[#1a4d3a] px-3 py-1 rounded-full text-sm font-semibold">
                        {item.time}
                      </span>
                    </div>
                    <h3 className="font-display text-xl font-bold text-[#f5f3f0] mb-2">
                      {item.activity}
                    </h3>
                    <p className="text-[#7a9471] leading-relaxed">
                      {item.description}
                    </p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Highlights */}
      <section className="section-padding">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="font-display text-4xl md:text-5xl font-bold text-[#f5f3f0] mb-6">
              Momentos <span className="text-[#d4af37]">Especiais</span>
            </h2>
            <p className="text-xl text-[#7a9471] max-w-3xl mx-auto">
              Experiências únicas que tornarão este evento verdadeiramente memorável
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {highlights.map((highlight, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.2 }}
                viewport={{ once: true }}
                className="relative group"
              >
                <div className="relative rounded-2xl overflow-hidden hover-lift">
                  <img  alt={highlight.description} className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-500" src="https://images.unsplash.com/photo-1595872018818-97555653a011" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
                  
                  <div className="absolute inset-0 flex items-end p-6">
                    <div>
                      <h3 className="font-display text-2xl font-bold text-[#f5f3f0] mb-2">
                        {highlight.title}
                      </h3>
                      <p className="text-[#f5f3f0]/90 leading-relaxed">
                        {highlight.description}
                      </p>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Community Section */}
      <section className="section-padding bg-black/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="relative"
            >
              <div className="relative rounded-2xl overflow-hidden hover-lift">
                <img  alt="Comunidade local participando no evento de inauguração" className="w-full h-96 object-cover" src="https://images.unsplash.com/photo-1693246346926-82f1e403cf0b" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent"></div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <h2 className="font-display text-4xl md:text-5xl font-bold text-[#f5f3f0] mb-6">
                Envolvimento da <span className="text-[#d4af37]">Comunidade</span>
              </h2>
              <div className="space-y-6 text-[#7a9471] text-lg leading-relaxed">
                <p>
                  A participação da população local é fundamental para o nosso projeto. 
                  O evento de inauguração celebra não apenas o início do Antiqua Silvanus, 
                  mas também a nossa parceria com a comunidade madeirense.
                </p>
                <p>
                  Artesãos, músicos, produtores locais e famílias da região serão 
                  protagonistas desta celebração, partilhando as suas tradições 
                  e conhecimentos com todos os participantes.
                </p>
                <p>
                  Esta colaboração representa o nosso compromisso com o turismo 
                  sustentável e o desenvolvimento local, criando benefícios mútuos 
                  para toda a comunidade.
                </p>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section-padding">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="glass-effect rounded-3xl p-12 hover-lift"
          >
            <h2 className="font-display text-4xl md:text-5xl font-bold text-[#f5f3f0] mb-6">
              Junte-se à <span className="text-[#d4af37]">Celebração</span>
            </h2>
            <p className="text-xl text-[#7a9471] mb-8 max-w-2xl mx-auto">
              Seja parte desta celebração única e ajude-nos a inaugurar um novo 
              capítulo do turismo sustentável na Madeira.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                onClick={handleRegistration}
                className="bg-[#d4af37] hover:bg-[#d4af37]/90 text-[#1a4d3a] font-semibold px-8 py-4 text-lg rounded-full hover-lift"
              >
                Registar Interesse
              </Button>
              
              <Button 
                onClick={handleRegistration}
                variant="outline" 
                className="border-[#f5f3f0] text-[#f5f3f0] hover:bg-[#f5f3f0] hover:text-[#1a4d3a] px-8 py-4 text-lg rounded-full hover-lift"
              >
                Mais Informações
              </Button>
            </div>
          </motion.div>
        </div>
      </section>
    </>
  );
};

export default Inauguration;