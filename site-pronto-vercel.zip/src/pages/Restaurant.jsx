import React from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { Clock, Utensils, Leaf, Wine, Mountain, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';

const Restaurant = () => {
  const menuCategories = [
    {
      name: "Pratos Regionais",
      description: "Sabores autênticos da tradição madeirense",
      icon: <Mountain className="h-6 w-6" />,
      dishes: [
        "Espetada Madeirense",
        "Caldeirada de Peixe",
        "Bolo do Caco",
        "Milho Frito",
        "Lapas Grelhadas"
      ]
    },
    {
      name: "Produtos Locais",
      description: "Ingredientes frescos da nossa região",
      icon: <Leaf className="h-6 w-6" />,
      dishes: [
        "Queijos da Madeira",
        "Mel de Cana",
        "Frutas Tropicais",
        "Ervas Aromáticas",
        "Peixe Fresco"
      ]
    },
    {
      name: "Opções Vegetarianas",
      description: "Pratos saudáveis e saborosos",
      icon: <Utensils className="h-6 w-6" />,
      dishes: [
        "Saladas Gourmet",
        "Sopas Naturais",
        "Pratos de Legumes",
        "Smoothies Tropicais",
        "Sobremesas Veganas"
      ]
    }
  ];

  const barSpecialties = [
    {
      name: "Cocktails Artesanais",
      description: "Criações únicas com ingredientes locais",
      items: [
        "Poncha Tradicional",
        "Mojito de Maracujá",
        "Caipirinha de Pitanga",
        "Gin Tónico com Ervas"
      ]
    },
    {
      name: "Vinhos da Madeira",
      description: "Seleção dos melhores vinhos regionais",
      items: [
        "Vinho Madeira Seco",
        "Vinho Madeira Doce",
        "Vinhos de Mesa",
        "Espumantes Locais"
      ]
    }
  ];

  const handleReservation = () => {
    toast({
      title: "🍽️ Reserva Solicitada!",
      description: "🚧 A funcionalidade de reserva de mesa ainda não está implementada—mas não se preocupe! Pode solicitar esta funcionalidade no seu próximo prompt! 🚀",
      duration: 5000,
    });
  };

  return (
    <>
      <Helmet>
        <title>Bar & Restaurante - Antiqua Silvanus Eco Lodge</title>
        <meta name="description" content="Restaurante com pratos regionais madeirenses, produtos locais e opções vegetarianas. Bar com cocktails artesanais e vinhos da Madeira. Esplanada com vista panorâmica." />
      </Helmet>

      {/* Hero Section */}
      <section className="relative min-h-[60vh] flex items-center justify-center overflow-hidden mt-20">
        <div className="absolute inset-0 z-0">
          <img  alt="Restaurante com vista panorâmica sobre o vale da Madeira" className="w-full h-full object-cover" src="https://images.unsplash.com/photo-1547498891-28325e814acf" />
          <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/30 to-black/60"></div>
        </div>

        <div className="relative z-10 text-center px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1 }}
            className="space-y-6"
          >
            <h1 className="font-display text-5xl md:text-6xl font-bold text-[#f5f3f0] text-shadow">
              Bar & <span className="text-[#d4af37]">Restaurante</span>
            </h1>
            <p className="text-xl md:text-2xl text-[#7a9471] max-w-3xl mx-auto">
              Sabores autênticos da Madeira com vista deslumbrante sobre o vale
            </p>
          </motion.div>
        </div>
      </section>

      {/* Restaurant Info */}
      <section className="section-padding">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <h2 className="font-display text-4xl md:text-5xl font-bold text-[#f5f3f0] mb-6">
                Experiência <span className="text-[#d4af37]">Gastronómica</span>
              </h2>
              <div className="space-y-6 text-[#7a9471] text-lg leading-relaxed">
                <p>
                  O nosso restaurante oferece uma experiência gastronómica única, 
                  combinando os sabores tradicionais madeirenses com ingredientes 
                  frescos e locais, numa atmosfera acolhedora e natural.
                </p>
                <p>
                  A nossa esplanada proporciona uma vista deslumbrante sobre o vale, 
                  criando o cenário perfeito para refeições memoráveis em contacto 
                  direto com a natureza.
                </p>
                <p>
                  Servimos desde o pequeno-almoço até ao jantar, sempre com foco 
                  na qualidade, sustentabilidade e autenticidade dos sabores regionais.
                </p>
              </div>

              <div className="mt-8 grid grid-cols-2 gap-6">
                <div className="glass-effect rounded-xl p-4 text-center">
                  <Clock className="h-8 w-8 text-[#d4af37] mx-auto mb-2" />
                  <div className="text-[#f5f3f0] font-semibold">Horário</div>
                  <div className="text-[#7a9471] text-sm">08h–22h</div>
                </div>
                <div className="glass-effect rounded-xl p-4 text-center">
                  <Star className="h-8 w-8 text-[#d4af37] mx-auto mb-2" />
                  <div className="text-[#f5f3f0] font-semibold">Vista</div>
                  <div className="text-[#7a9471] text-sm">Panorâmica</div>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="relative"
            >
              <div className="relative rounded-2xl overflow-hidden hover-lift">
                <img  alt="Pratos regionais madeirenses servidos no restaurante" className="w-full h-96 object-cover" src="https://images.unsplash.com/photo-1591741136763-25bfbc570c53" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent"></div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Menu Categories */}
      <section className="section-padding bg-black/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="font-display text-4xl md:text-5xl font-bold text-[#f5f3f0] mb-6">
              Nossa <span className="text-[#d4af37]">Cozinha</span>
            </h2>
            <p className="text-xl text-[#7a9471] max-w-3xl mx-auto">
              Descubra os sabores autênticos da Madeira através da nossa seleção cuidadosa
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {menuCategories.map((category, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.2 }}
                viewport={{ once: true }}
                className="glass-effect rounded-2xl p-8 hover-lift"
              >
                <div className="text-center mb-6">
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-[#d4af37]/20 rounded-full mb-4">
                    <div className="text-[#d4af37]">
                      {category.icon}
                    </div>
                  </div>
                  <h3 className="font-display text-2xl font-bold text-[#f5f3f0] mb-2">
                    {category.name}
                  </h3>
                  <p className="text-[#7a9471] text-sm">
                    {category.description}
                  </p>
                </div>

                <div className="space-y-3">
                  {category.dishes.map((dish, dishIndex) => (
                    <div key={dishIndex} className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-[#d4af37] rounded-full"></div>
                      <span className="text-[#f5f3f0] text-sm">{dish}</span>
                    </div>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Bar Section */}
      <section className="section-padding">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="font-display text-4xl md:text-5xl font-bold text-[#f5f3f0] mb-6">
              Nosso <span className="text-[#d4af37]">Bar</span>
            </h2>
            <p className="text-xl text-[#7a9471] max-w-3xl mx-auto">
              Cocktails artesanais e vinhos selecionados numa atmosfera única
            </p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {barSpecialties.map((specialty, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.2 }}
                viewport={{ once: true }}
                className="glass-effect rounded-2xl p-8 hover-lift"
              >
                <div className="flex items-center space-x-4 mb-6">
                  <Wine className="h-8 w-8 text-[#d4af37]" />
                  <div>
                    <h3 className="font-display text-2xl font-bold text-[#f5f3f0]">
                      {specialty.name}
                    </h3>
                    <p className="text-[#7a9471] text-sm">
                      {specialty.description}
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {specialty.items.map((item, itemIndex) => (
                    <div key={itemIndex} className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-[#d4af37] rounded-full"></div>
                      <span className="text-[#f5f3f0] text-sm">{item}</span>
                    </div>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Terrace Section */}
      <section className="section-padding bg-black/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="relative"
            >
              <div className="relative rounded-2xl overflow-hidden hover-lift">
                <img  alt="Esplanada do restaurante com vista panorâmica sobre o vale" className="w-full h-96 object-cover" src="https://images.unsplash.com/photo-1547498891-28325e814acf" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent"></div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <h2 className="font-display text-4xl md:text-5xl font-bold text-[#f5f3f0] mb-6">
                Esplanada com <span className="text-[#d4af37]">Vista</span>
              </h2>
              <div className="space-y-6 text-[#7a9471] text-lg leading-relaxed">
                <p>
                  A nossa esplanada é o local perfeito para desfrutar de uma refeição 
                  ou bebida enquanto aprecia a vista deslumbrante sobre o vale da Madeira.
                </p>
                <p>
                  Rodeada pela natureza exuberante da floresta Laurissilva, oferece 
                  um ambiente tranquilo e inspirador, ideal para momentos especiais 
                  ou simplesmente para relaxar.
                </p>
                <p>
                  Aberta durante todo o dia, proporciona experiências únicas desde 
                  o nascer do sol até ao pôr do sol, sempre com o melhor da nossa 
                  gastronomia e hospitalidade.
                </p>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section-padding">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="glass-effect rounded-3xl p-12 hover-lift"
          >
            <h2 className="font-display text-4xl md:text-5xl font-bold text-[#f5f3f0] mb-6">
              Reserve a Sua <span className="text-[#d4af37]">Mesa</span>
            </h2>
            <p className="text-xl text-[#7a9471] mb-8 max-w-2xl mx-auto">
              Garanta o seu lugar na nossa esplanada e desfrute de uma experiência 
              gastronómica única com vista panorâmica sobre o vale.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                onClick={handleReservation}
                className="bg-[#d4af37] hover:bg-[#d4af37]/90 text-[#1a4d3a] font-semibold px-8 py-4 text-lg rounded-full hover-lift"
              >
                Reservar Mesa
              </Button>
              
              <Button 
                onClick={handleReservation}
                variant="outline" 
                className="border-[#f5f3f0] text-[#f5f3f0] hover:bg-[#f5f3f0] hover:text-[#1a4d3a] px-8 py-4 text-lg rounded-full hover-lift"
              >
                Ver Menu Completo
              </Button>
            </div>
          </motion.div>
        </div>
      </section>
    </>
  );
};

export default Restaurant;