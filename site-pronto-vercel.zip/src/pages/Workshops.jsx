import React from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { Users, Clock, Award, Heart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';

const Workshops = () => {

  const handleBookWorkshop = (workshopName) => {
    toast({
      title: "🎨 Workshop Selecionado!",
      description: `🚧 A funcionalidade de reserva para ${workshopName} ainda não está implementada—mas não se preocupe! Pode solicitar esta funcionalidade no seu próximo prompt! 🚀`,
      duration: 5000,
    });
  };
  
  const workshopHighlights = {
      pao: ["Receitas tradicionais madeirenses", "Ingredientes locais e biológicos", "Técnicas ancestrais", "Degustação incluída", "Receita para levar"],
      cestaria: ["Materiais naturais da região", "Técnicas tradicionais", "Peça personalizada", "Artesão local", "História da cestaria"],
      cosmetica: ["Plantas da floresta Laurissilva", "Produtos 100% naturais", "Receitas exclusivas", "Kit para levar", "Benefícios terapêuticos"],
      poncha: ["Receita tradicional", "Ingredientes autênticos", "Técnicas dos mestres", "Degustação variada", "História da bebida"]
  };

  return (
    <>
      <Helmet>
        <title>Workshops e Experiências - Antiqua Silvanus Eco Lodge</title>
        <meta name="description" content="Participe nos nossos workshops autênticos: oficinas de pão, cestaria, cosmética natural e poncha. Encontros com artesãos e visitas a produtores locais." />
      </Helmet>

      {/* Hero Section */}
      <section className="relative min-h-[60vh] flex items-center justify-center overflow-hidden mt-20">
        <div className="absolute inset-0 z-0">
          <img  alt="Workshops tradicionais madeirenses com artesãos locais" className="w-full h-full object-cover" src="https://images.unsplash.com/photo-1691438000323-f0dc17c29d9d" />
          <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/30 to-black/60"></div>
        </div>

        <div className="relative z-10 text-center px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1 }}
            className="space-y-6"
          >
            <h1 className="font-display text-5xl md:text-6xl font-bold text-[#f5f3f0] text-shadow">
              Workshops & <span className="text-[#d4af37]">Experiências</span>
            </h1>
            <p className="text-xl md:text-2xl text-[#7a9471] max-w-3xl mx-auto">
              Descubra as tradições madeirenses através de experiências autênticas e workshops únicos
            </p>
          </motion.div>
        </div>
      </section>

      {/* Workshops Section */}
      <section className="section-padding">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="font-display text-4xl md:text-5xl font-bold text-[#f5f3f0] mb-6">
              Oficinas <span className="text-[#d4af37]">Tradicionais</span>
            </h2>
            <p className="text-xl text-[#7a9471] max-w-3xl mx-auto">
              Aprenda técnicas ancestrais com mestres locais e leve consigo conhecimentos únicos
            </p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Oficina de Pão Tradicional */}
            <motion.div initial={{ opacity: 0, y: 50 }} whileInView={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 0.1 }} viewport={{ once: true }} className="glass-effect rounded-2xl overflow-hidden hover-lift group">
                <div className="relative h-64">
                    <img  alt="Oficina de pão tradicional com ingredientes locais" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" src="https://images.unsplash.com/photo-1676138937647-c68e56bc5c4e" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                    <div className="absolute bottom-4 left-4 right-4"><div className="flex justify-between items-end"><div className="glass-effect rounded-xl p-3"><div className="flex items-center space-x-4 text-[#f5f3f0] text-sm"><div className="flex items-center space-x-1"><Clock className="h-4 w-4" /><span>3 horas</span></div><div className="flex items-center space-x-1"><Users className="h-4 w-4" /><span>Máx. 8 pessoas</span></div></div></div></div></div>
                </div>
                <div className="p-8 space-y-6">
                    <div><h3 className="font-display text-2xl font-bold text-[#f5f3f0] mb-3">Oficina de Pão Tradicional</h3><p className="text-[#7a9471] leading-relaxed">Aprenda a fazer pão tradicional madeirense com ingredientes locais e técnicas ancestrais transmitidas de geração em geração.</p></div>
                    <div className="space-y-3"><h4 className="font-semibold text-[#f5f3f0]">Inclui:</h4><div className="grid grid-cols-1 gap-2">{workshopHighlights.pao.map((h, i) => (<div key={i} className="flex items-center space-x-2"><div className="w-2 h-2 bg-[#d4af37] rounded-full"></div><span className="text-[#7a9471] text-sm">{h}</span></div>))}</div></div>
                    <div className="pt-4"><Button onClick={() => handleBookWorkshop("Oficina de Pão Tradicional")} className="w-full bg-[#d4af37] hover:bg-[#d4af37]/90 text-[#1a4d3a] font-semibold py-3 rounded-full">Inscrever-se</Button></div>
                </div>
            </motion.div>

            {/* Cestaria Artesanal */}
            <motion.div initial={{ opacity: 0, y: 50 }} whileInView={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 0.2 }} viewport={{ once: true }} className="glass-effect rounded-2xl overflow-hidden hover-lift group">
                <div className="relative h-64">
                    <img  alt="Oficina de cestaria artesanal com materiais naturais" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" src="https://images.unsplash.com/flagged/photo-1567056746593-0f538ff7d065" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                    <div className="absolute bottom-4 left-4 right-4"><div className="flex justify-between items-end"><div className="glass-effect rounded-xl p-3"><div className="flex items-center space-x-4 text-[#f5f3f0] text-sm"><div className="flex items-center space-x-1"><Clock className="h-4 w-4" /><span>4 horas</span></div><div className="flex items-center space-x-1"><Users className="h-4 w-4" /><span>Máx. 6 pessoas</span></div></div></div></div></div>
                </div>
                <div className="p-8 space-y-6">
                    <div><h3 className="font-display text-2xl font-bold text-[#f5f3f0] mb-3">Cestaria Artesanal</h3><p className="text-[#7a9471] leading-relaxed">Descubra a arte tradicional da cestaria madeirense, criando peças únicas com materiais naturais da região.</p></div>
                    <div className="space-y-3"><h4 className="font-semibold text-[#f5f3f0]">Inclui:</h4><div className="grid grid-cols-1 gap-2">{workshopHighlights.cestaria.map((h, i) => (<div key={i} className="flex items-center space-x-2"><div className="w-2 h-2 bg-[#d4af37] rounded-full"></div><span className="text-[#7a9471] text-sm">{h}</span></div>))}</div></div>
                    <div className="pt-4"><Button onClick={() => handleBookWorkshop("Cestaria Artesanal")} className="w-full bg-[#d4af37] hover:bg-[#d4af37]/90 text-[#1a4d3a] font-semibold py-3 rounded-full">Inscrever-se</Button></div>
                </div>
            </motion.div>
            
            {/* Cosmética Natural */}
            <motion.div initial={{ opacity: 0, y: 50 }} whileInView={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 0.3 }} viewport={{ once: true }} className="glass-effect rounded-2xl overflow-hidden hover-lift group">
                <div className="relative h-64">
                    <img  alt="Oficina de cosmética natural com plantas da floresta" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" src="https://images.unsplash.com/photo-1688484839099-12620e05e562" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                    <div className="absolute bottom-4 left-4 right-4"><div className="flex justify-between items-end"><div className="glass-effect rounded-xl p-3"><div className="flex items-center space-x-4 text-[#f5f3f0] text-sm"><div className="flex items-center space-x-1"><Clock className="h-4 w-4" /><span>2.5 horas</span></div><div className="flex items-center space-x-1"><Users className="h-4 w-4" /><span>Máx. 10 pessoas</span></div></div></div></div></div>
                </div>
                <div className="p-8 space-y-6">
                    <div><h3 className="font-display text-2xl font-bold text-[#f5f3f0] mb-3">Cosmética Natural</h3><p className="text-[#7a9471] leading-relaxed">Crie os seus próprios produtos de cosmética natural utilizando plantas e ingredientes da floresta Laurissilva.</p></div>
                    <div className="space-y-3"><h4 className="font-semibold text-[#f5f3f0]">Inclui:</h4><div className="grid grid-cols-1 gap-2">{workshopHighlights.cosmetica.map((h, i) => (<div key={i} className="flex items-center space-x-2"><div className="w-2 h-2 bg-[#d4af37] rounded-full"></div><span className="text-[#7a9471] text-sm">{h}</span></div>))}</div></div>
                    <div className="pt-4"><Button onClick={() => handleBookWorkshop("Cosmética Natural")} className="w-full bg-[#d4af37] hover:bg-[#d4af37]/90 text-[#1a4d3a] font-semibold py-3 rounded-full">Inscrever-se</Button></div>
                </div>
            </motion.div>
            
            {/* Oficina de Poncha */}
            <motion.div initial={{ opacity: 0, y: 50 }} whileInView={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 0.4 }} viewport={{ once: true }} className="glass-effect rounded-2xl overflow-hidden hover-lift group">
                <div className="relative h-64">
                    <img  alt="Oficina de poncha tradicional madeirense" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" src="https://images.unsplash.com/photo-1603955813288-c89f4ad8b1e1" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                    <div className="absolute bottom-4 left-4 right-4"><div className="flex justify-between items-end"><div className="glass-effect rounded-xl p-3"><div className="flex items-center space-x-4 text-[#f5f3f0] text-sm"><div className="flex items-center space-x-1"><Clock className="h-4 w-4" /><span>2 horas</span></div><div className="flex items-center space-x-1"><Users className="h-4 w-4" /><span>Máx. 12 pessoas</span></div></div></div></div></div>
                </div>
                <div className="p-8 space-y-6">
                    <div><h3 className="font-display text-2xl font-bold text-[#f5f3f0] mb-3">Oficina de Poncha</h3><p className="text-[#7a9471] leading-relaxed">Aprenda a preparar a famosa poncha madeirense com os segredos dos mestres locais e ingredientes autênticos.</p></div>
                    <div className="space-y-3"><h4 className="font-semibold text-[#f5f3f0]">Inclui:</h4><div className="grid grid-cols-1 gap-2">{workshopHighlights.poncha.map((h, i) => (<div key={i} className="flex items-center space-x-2"><div className="w-2 h-2 bg-[#d4af37] rounded-full"></div><span className="text-[#7a9471] text-sm">{h}</span></div>))}</div></div>
                    <div className="pt-4"><Button onClick={() => handleBookWorkshop("Oficina de Poncha")} className="w-full bg-[#d4af37] hover:bg-[#d4af37]/90 text-[#1a4d3a] font-semibold py-3 rounded-full">Inscrever-se</Button></div>
                </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Experiences Section */}
      <section className="section-padding bg-black/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="font-display text-4xl md:text-5xl font-bold text-[#f5f3f0] mb-6">
              Experiências <span className="text-[#d4af37]">Culturais</span>
            </h2>
            <p className="text-xl text-[#7a9471] max-w-3xl mx-auto">
              Conecte-se com a cultura local através de encontros autênticos
            </p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Visitas a Produtores Locais */}
            <motion.div initial={{ opacity: 0, y: 50 }} whileInView={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 0.2 }} viewport={{ once: true }} className="relative">
                <div className="relative rounded-2xl overflow-hidden hover-lift group">
                    <img  alt="Visita a produtores locais na Madeira" className="w-full h-80 object-cover group-hover:scale-105 transition-transform duration-500" src="https://images.unsplash.com/photo-1460008511804-34e22c2bf15a" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
                    <div className="absolute inset-0 flex items-end p-8">
                        <div className="space-y-4">
                            <div className="inline-flex items-center justify-center w-12 h-12 bg-[#d4af37]/90 rounded-full text-[#1a4d3a]"><Users className="h-8 w-8" /></div>
                            <div>
                                <h3 className="font-display text-2xl font-bold text-[#f5f3f0] mb-2">Visitas a Produtores Locais</h3>
                                <p className="text-[#f5f3f0]/90 leading-relaxed">Conheça os produtores locais e descubra os segredos por trás dos melhores produtos madeirenses.</p>
                            </div>
                            <Button onClick={() => handleBookWorkshop("Visitas a Produtores Locais")} className="bg-[#d4af37] hover:bg-[#d4af37]/90 text-[#1a4d3a] font-semibold px-6 py-2 rounded-full">Saber Mais</Button>
                        </div>
                    </div>
                </div>
            </motion.div>

            {/* Encontros com Artesãos */}
            <motion.div initial={{ opacity: 0, y: 50 }} whileInView={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 0.4 }} viewport={{ once: true }} className="relative">
                <div className="relative rounded-2xl overflow-hidden hover-lift group">
                    <img  alt="Encontro com artesãos madeirenses" className="w-full h-80 object-cover group-hover:scale-105 transition-transform duration-500" src="https://images.unsplash.com/photo-1680188700662-5b03bdcf3017" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
                    <div className="absolute inset-0 flex items-end p-8">
                        <div className="space-y-4">
                            <div className="inline-flex items-center justify-center w-12 h-12 bg-[#d4af37]/90 rounded-full text-[#1a4d3a]"><Award className="h-8 w-8" /></div>
                            <div>
                                <h3 className="font-display text-2xl font-bold text-[#f5f3f0] mb-2">Encontros com Artesãos</h3>
                                <p className="text-[#f5f3f0]/90 leading-relaxed">Interaja com artesãos madeirenses e aprenda sobre as tradições culturais da ilha.</p>
                            </div>
                            <Button onClick={() => handleBookWorkshop("Encontros com Artesãos")} className="bg-[#d4af37] hover:bg-[#d4af37]/90 text-[#1a4d3a] font-semibold px-6 py-2 rounded-full">Saber Mais</Button>
                        </div>
                    </div>
                </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Info Section */}
      <section className="section-padding">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <h2 className="font-display text-4xl md:text-5xl font-bold text-[#f5f3f0] mb-6">
                Tradições <span className="text-[#d4af37]">Autênticas</span>
              </h2>
              <div className="space-y-6 text-[#7a9471] text-lg leading-relaxed">
                <p>
                  Os nossos workshops são conduzidos por mestres locais que preservam 
                  as tradições madeirenses há gerações. Cada experiência é uma oportunidade 
                  única de aprender técnicas ancestrais.
                </p>
                <p>
                  Utilizamos apenas materiais locais e ingredientes autênticos, 
                  garantindo que cada participante leva consigo não apenas conhecimento, 
                  mas também uma peça da cultura madeirense.
                </p>
                <p>
                  Estas experiências promovem o turismo sustentável e apoiam as 
                  comunidades locais, preservando o património cultural da Madeira.
                </p>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="relative"
            >
              <div className="relative rounded-2xl overflow-hidden hover-lift">
                <img  alt="Mestre artesão madeirense ensinando técnicas tradicionais" className="w-full h-96 object-cover" src="https://images.unsplash.com/photo-1539655190995-b63bbe5ddf8a" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent"></div>
                
                <div className="absolute bottom-6 left-6 glass-effect rounded-xl p-4">
                  <div className="flex items-center space-x-2 text-[#f5f3f0]">
                    <Heart className="h-5 w-5 text-[#d4af37]" />
                    <span className="font-semibold">Tradições Preservadas</span>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section-padding bg-black/20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="glass-effect rounded-3xl p-12 hover-lift"
          >
            <h2 className="font-display text-4xl md:text-5xl font-bold text-[#f5f3f0] mb-6">
              Crie Memórias <span className="text-[#d4af37]">Únicas</span>
            </h2>
            <p className="text-xl text-[#7a9471] mb-8 max-w-2xl mx-auto">
              Participe nos nossos workshops e leve consigo não apenas conhecimento, 
              mas também uma parte autêntica da cultura madeirense.
            </p>
            
            <Button 
              onClick={() => handleBookWorkshop("qualquer workshop")}
              className="bg-[#d4af37] hover:bg-[#d4af37]/90 text-[#1a4d3a] font-semibold px-8 py-4 text-lg rounded-full hover-lift"
            >
              Reservar Workshop
            </Button>
          </motion.div>
        </div>
      </section>
    </>
  );
};

export default Workshops;