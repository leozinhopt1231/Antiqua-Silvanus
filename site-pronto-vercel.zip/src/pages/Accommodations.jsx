import React from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { Users, Bed, Coffee, Eye, Wifi, Car } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';

const Accommodations = () => {
  const handleBooking = (accommodationName) => {
    toast({
      title: "🏡 Reserva Solicitada!",
      description: `🚧 A funcionalidade de reserva para ${accommodationName} ainda não está implementada—mas não se preocupe! Pode solicitar esta funcionalidade no seu próximo prompt! 🚀`,
      duration: 5000,
    });
  };
  
  const accommodationFeatures = {
    cabanas: [ "Cama de casal confortável", "Kitchenette equipada", "Varanda panorâmica", "Vista para a floresta", "Wi-Fi gratuito", "Estacionamento" ],
    suites: [ "Cama king-size", "Jacuzzi privativo", "Lareira", "Sala de estar", "Varanda privada", "Serviço de quarto" ],
    lodges: [ "2 quartos separados", "Sala ampla", "Terraço privativo", "Cozinha completa", "2 casas de banho", "Área de jogos" ],
  };

  return (
    <>
      <Helmet>
        <title>Alojamentos - Antiqua Silvanus Eco Lodge</title>
        <meta name="description" content="Descubra os nossos alojamentos únicos na floresta Laurissilva: Cabanas Florestais, Suites Premium e Lodges Familiares. Conforto e natureza em perfeita harmonia." />
      </Helmet>

      {/* Hero Section */}
      <section className="relative min-h-[60vh] flex items-center justify-center overflow-hidden mt-20">
        <div className="absolute inset-0 z-0">
          <img  alt="Alojamentos eco-friendly integrados na floresta Laurissilva" className="w-full h-full object-cover" src="https://images.unsplash.com/photo-1635584365164-3a50d17576b9" />
          <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/30 to-black/60"></div>
        </div>

        <div className="relative z-10 text-center px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1 }}
            className="space-y-6"
          >
            <h1 className="font-display text-5xl md:text-6xl font-bold text-[#f5f3f0] text-shadow">
              Nossos <span className="text-[#d4af37]">Alojamentos</span>
            </h1>
            <p className="text-xl md:text-2xl text-[#7a9471] max-w-3xl mx-auto">
              Experiências únicas de hospedagem integradas na floresta Laurissilva
            </p>
          </motion.div>
        </div>
      </section>

      {/* Accommodations Grid */}
      <section className="section-padding">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="space-y-16">
            {/* Cabanas Florestais */}
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center"
            >
              <div className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="inline-block bg-[#d4af37]/20 text-[#d4af37] px-4 py-2 rounded-full text-sm font-semibold">2 Cabanas</span>
                    <span className="font-display text-3xl font-bold text-[#d4af37]">90€/noite</span>
                  </div>
                  <h2 className="font-display text-4xl md:text-5xl font-bold text-[#f5f3f0]">Cabanas Florestais</h2>
                  <p className="text-lg text-[#7a9471] leading-relaxed">Cabanas acolhedoras com cama de casal, kitchenette totalmente equipada e varanda panorâmica com vista deslumbrante sobre a floresta.</p>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  {accommodationFeatures.cabanas.map((feature, i) => (
                    <div key={i} className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-[#d4af37] rounded-full"></div>
                      <span className="text-[#7a9471] text-sm">{feature}</span>
                    </div>
                  ))}
                </div>
                <div className="flex items-center space-x-6 pt-4">
                  <div className="flex items-center space-x-2">
                    <Users className="h-5 w-5 text-[#d4af37]" />
                    <span className="text-[#f5f3f0] font-medium">2 pessoas</span>
                  </div>
                </div>
                <div className="pt-6">
                  <Button onClick={() => handleBooking("Cabanas Florestais")} className="bg-[#d4af37] hover:bg-[#d4af37]/90 text-[#1a4d3a] font-semibold px-8 py-4 rounded-full hover-lift">Reservar Agora</Button>
                </div>
              </div>
              <div className="relative">
                <div className="relative rounded-2xl overflow-hidden hover-lift">
                  <img  alt="Cabana Florestal com varanda panorâmica e vista para a floresta" className="w-full h-96 lg:h-[500px] object-cover" src="https://images.unsplash.com/photo-1566754844421-9bc834baf4a3" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent"></div>
                  <div className="absolute top-6 left-6 glass-effect rounded-xl p-4">
                    <div className="text-[#f5f3f0] font-display text-2xl font-bold">90€/noite</div>
                    <div className="text-[#7a9471] text-sm">por noite</div>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Suites Premium */}
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center"
            >
              <div className="space-y-6 lg:col-start-2">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="inline-block bg-[#d4af37]/20 text-[#d4af37] px-4 py-2 rounded-full text-sm font-semibold">2 Suites</span>
                    <span className="font-display text-3xl font-bold text-[#d4af37]">130€/noite</span>
                  </div>
                  <h2 className="font-display text-4xl md:text-5xl font-bold text-[#f5f3f0]">Suites Premium</h2>
                  <p className="text-lg text-[#7a9471] leading-relaxed">Suites luxuosas com cama king-size, jacuzzi privativo e lareira acolhedora para momentos românticos únicos na natureza.</p>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  {accommodationFeatures.suites.map((feature, i) => (
                    <div key={i} className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-[#d4af37] rounded-full"></div>
                      <span className="text-[#7a9471] text-sm">{feature}</span>
                    </div>
                  ))}
                </div>
                <div className="flex items-center space-x-6 pt-4">
                  <div className="flex items-center space-x-2">
                    <Users className="h-5 w-5 text-[#d4af37]" />
                    <span className="text-[#f5f3f0] font-medium">2 pessoas</span>
                  </div>
                </div>
                <div className="pt-6">
                  <Button onClick={() => handleBooking("Suites Premium")} className="bg-[#d4af37] hover:bg-[#d4af37]/90 text-[#1a4d3a] font-semibold px-8 py-4 rounded-full hover-lift">Reservar Agora</Button>
                </div>
              </div>
              <div className="relative lg:col-start-1">
                <div className="relative rounded-2xl overflow-hidden hover-lift">
                  <img  alt="Suite Premium com cama king-size, jacuzzi e lareira" className="w-full h-96 lg:h-[500px] object-cover" src="https://images.unsplash.com/photo-1703193376968-cca301c3a70d" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent"></div>
                  <div className="absolute top-6 left-6 glass-effect rounded-xl p-4">
                    <div className="text-[#f5f3f0] font-display text-2xl font-bold">130€/noite</div>
                    <div className="text-[#7a9471] text-sm">por noite</div>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Lodges Familiares */}
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center"
            >
              <div className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="inline-block bg-[#d4af37]/20 text-[#d4af37] px-4 py-2 rounded-full text-sm font-semibold">2 Lodges</span>
                    <span className="font-display text-3xl font-bold text-[#d4af37]">160€/noite</span>
                  </div>
                  <h2 className="font-display text-4xl md:text-5xl font-bold text-[#f5f3f0]">Lodges Familiares</h2>
                  <p className="text-lg text-[#7a9471] leading-relaxed">Lodges espaçosos com 2 quartos, sala ampla e terraço privativo, perfeitos para famílias que procuram conforto e privacidade.</p>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  {accommodationFeatures.lodges.map((feature, i) => (
                    <div key={i} className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-[#d4af37] rounded-full"></div>
                      <span className="text-[#7a9471] text-sm">{feature}</span>
                    </div>
                  ))}
                </div>
                <div className="flex items-center space-x-6 pt-4">
                  <div className="flex items-center space-x-2">
                    <Users className="h-5 w-5 text-[#d4af37]" />
                    <span className="text-[#f5f3f0] font-medium">4-6 pessoas</span>
                  </div>
                </div>
                <div className="pt-6">
                  <Button onClick={() => handleBooking("Lodges Familiares")} className="bg-[#d4af37] hover:bg-[#d4af37]/90 text-[#1a4d3a] font-semibold px-8 py-4 rounded-full hover-lift">Reservar Agora</Button>
                </div>
              </div>
              <div className="relative">
                <div className="relative rounded-2xl overflow-hidden hover-lift">
                  <img  alt="Lodge Familiar espaçoso com terraço e vista para a floresta" className="w-full h-96 lg:h-[500px] object-cover" src="https://images.unsplash.com/photo-1703631092767-926061620be7" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent"></div>
                  <div className="absolute top-6 left-6 glass-effect rounded-xl p-4">
                    <div className="text-[#f5f3f0] font-display text-2xl font-bold">160€/noite</div>
                    <div className="text-[#7a9471] text-sm">por noite</div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Amenities Section */}
      <section className="section-padding bg-black/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="font-display text-4xl md:text-5xl font-bold text-[#f5f3f0] mb-6">
              Comodidades <span className="text-[#d4af37]">Incluídas</span>
            </h2>
            <p className="text-xl text-[#7a9471] max-w-3xl mx-auto">
              Todos os nossos alojamentos incluem comodidades essenciais para uma estadia perfeita
            </p>
          </motion.div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8">
            {[
              { icon: <Wifi className="h-8 w-8" />, name: "Wi-Fi Gratuito" },
              { icon: <Car className="h-8 w-8" />, name: "Estacionamento" },
              { icon: <Coffee className="h-8 w-8" />, name: "Café da Manhã" },
              { icon: <Eye className="h-8 w-8" />, name: "Vista Floresta" },
              { icon: <Bed className="h-8 w-8" />, name: "Roupa de Cama" },
              { icon: <Users className="h-8 w-8" />, name: "Recepção 24h" }
            ].map((amenity, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="text-center space-y-4"
              >
                <div className="inline-flex items-center justify-center w-16 h-16 bg-[#d4af37]/20 rounded-full text-[#d4af37]">
                  {amenity.icon}
                </div>
                <p className="text-[#f5f3f0] font-medium text-sm">{amenity.name}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section-padding">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="glass-effect rounded-3xl p-12 hover-lift"
          >
            <h2 className="font-display text-4xl md:text-5xl font-bold text-[#f5f3f0] mb-6">
              Reserve a Sua <span className="text-[#d4af37]">Experiência</span>
            </h2>
            <p className="text-xl text-[#7a9471] mb-8 max-w-2xl mx-auto">
              Contacte-nos para mais informações sobre disponibilidade e reservas. 
              A nossa equipa está pronta para tornar a sua estadia inesquecível.
            </p>
            
            <Button 
              onClick={() => handleBooking("qualquer alojamento")}
              className="bg-[#d4af37] hover:bg-[#d4af37]/90 text-[#1a4d3a] font-semibold px-8 py-4 text-lg rounded-full hover-lift"
            >
              Contactar para Reservas
            </Button>
          </motion.div>
        </div>
      </section>
    </>
  );
};

export default Accommodations;