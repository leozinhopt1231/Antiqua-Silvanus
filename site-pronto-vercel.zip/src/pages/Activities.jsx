import React from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { Clock, Euro, Users, MapPin, Glasses as Binoculars, Moon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';

const Activities = () => {
  const handleBookActivity = (activityName) => {
    toast({
      title: "🌿 Atividade Selecionada!",
      description: `🚧 A funcionalidade de reserva para ${activityName} ainda não está implementada—mas não se preocupe! Pode solicitar esta funcionalidade no seu próximo prompt! 🚀`,
      duration: 5000,
    });
  };

  const activityHighlights = {
    trilhos: ["Guia especializado em botânica", "Descoberta da flora endémica", "História da floresta Laurissilva", "Observação de espécies raras", "Fotografia da natureza"],
    yoga: ["Instrutor certificado", "Locais únicos na floresta", "Equipamento incluído", "Técnicas de respiração", "Relaxamento profundo"],
    aves: ["Binóculos profissionais", "Guia ornitológico", "Espécies endémicas", "Registo de observações", "Material educativo"],
    noturnas: ["Lanternas fornecidas", "Observação de estrelas", "Sons da natureza", "Experiência única", "Segurança garantida"],
    piqueniques: ["Produtos locais", "Locais únicos", "Cestas personalizadas", "Opções vegetarianas", "Experiência romântica"]
  };

  return (
    <>
      <Helmet>
        <title>Atividades - Antiqua Silvanus Eco Lodge</title>
        <meta name="description" content="Descubra as nossas atividades na floresta Laurissilva: trilhos guiados, yoga na natureza, observação de aves, caminhadas noturnas e piqueniques únicos." />
      </Helmet>

      {/* Hero Section */}
      <section className="relative min-h-[60vh] flex items-center justify-center overflow-hidden mt-20">
        <div className="absolute inset-0 z-0">
          <img  alt="Atividades na floresta Laurissilva da Madeira" className="w-full h-full object-cover" src="https://images.unsplash.com/photo-1516112928934-ef1fb3ec7806" />
          <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/30 to-black/60"></div>
        </div>

        <div className="relative z-10 text-center px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1 }}
            className="space-y-6"
          >
            <h1 className="font-display text-5xl md:text-6xl font-bold text-[#f5f3f0] text-shadow">
              Nossas <span className="text-[#d4af37]">Atividades</span>
            </h1>
            <p className="text-xl md:text-2xl text-[#7a9471] max-w-3xl mx-auto">
              Experiências únicas para conectar com a natureza da floresta Laurissilva
            </p>
          </motion.div>
        </div>
      </section>

      {/* Activities Grid */}
      <section className="section-padding">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Trilhos Interpretativos Guiados */}
            <motion.div initial={{ opacity: 0, y: 50 }} whileInView={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 0.1 }} viewport={{ once: true }} className="glass-effect rounded-2xl overflow-hidden hover-lift group">
                <div className="relative h-64">
                    <img  alt="Trilho guiado na floresta Laurissilva" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" src="https://images.unsplash.com/photo-1696613640185-0b61d0006c8e" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                    <div className="absolute top-4 left-4 bg-[#d4af37]/90 rounded-full p-3"><div className="text-[#1a4d3a]"><MapPin className="h-8 w-8" /></div></div>
                    <div className="absolute bottom-4 right-4 glass-effect rounded-xl p-3"><div className="flex items-center space-x-4 text-[#f5f3f0]"><div className="flex items-center space-x-1"><Clock className="h-4 w-4" /><span className="text-sm font-medium">2h30</span></div><div className="flex items-center space-x-1"><Euro className="h-4 w-4" /><span className="text-sm font-medium">15€</span></div></div></div>
                </div>
                <div className="p-8 space-y-6">
                    <div>
                        <h3 className="font-display text-2xl font-bold text-[#f5f3f0] mb-3">Trilhos Interpretativos Guiados</h3>
                        <p className="text-[#7a9471] leading-relaxed">Descubra os segredos da floresta Laurissilva com os nossos guias especializados. Uma jornada educativa através da biodiversidade única desta floresta património da UNESCO.</p>
                    </div>
                    <div className="space-y-3">
                        <h4 className="font-semibold text-[#f5f3f0]">Destaques:</h4>
                        <div className="grid grid-cols-1 gap-2">
                            {activityHighlights.trilhos.map((highlight, i) => (<div key={i} className="flex items-center space-x-2"><div className="w-2 h-2 bg-[#d4af37] rounded-full"></div><span className="text-[#7a9471] text-sm">{highlight}</span></div>))}
                        </div>
                    </div>
                    <div className="pt-4"><Button onClick={() => handleBookActivity("Trilhos Interpretativos Guiados")} className="w-full bg-[#d4af37] hover:bg-[#d4af37]/90 text-[#1a4d3a] font-semibold py-3 rounded-full">Reservar Atividade</Button></div>
                </div>
            </motion.div>

            {/* Yoga e Meditação na Natureza */}
            <motion.div initial={{ opacity: 0, y: 50 }} whileInView={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 0.2 }} viewport={{ once: true }} className="glass-effect rounded-2xl overflow-hidden hover-lift group">
                <div className="relative h-64">
                    <img  alt="Sessão de yoga numa clareira da floresta" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" src="https://images.unsplash.com/photo-1561577631-ef906796fbe0" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                    <div className="absolute top-4 left-4 bg-[#d4af37]/90 rounded-full p-3"><div className="text-[#1a4d3a]"><Users className="h-8 w-8" /></div></div>
                    <div className="absolute bottom-4 right-4 glass-effect rounded-xl p-3"><div className="flex items-center space-x-4 text-[#f5f3f0]"><div className="flex items-center space-x-1"><Clock className="h-4 w-4" /><span className="text-sm font-medium">1h</span></div><div className="flex items-center space-x-1"><Euro className="h-4 w-4" /><span className="text-sm font-medium">25€</span></div></div></div>
                </div>
                <div className="p-8 space-y-6">
                    <div>
                        <h3 className="font-display text-2xl font-bold text-[#f5f3f0] mb-3">Yoga e Meditação na Natureza</h3>
                        <p className="text-[#7a9471] leading-relaxed">Conecte-se consigo mesmo e com a natureza através de sessões de yoga e meditação em locais únicos da floresta, proporcionando paz interior e bem-estar.</p>
                    </div>
                    <div className="space-y-3">
                        <h4 className="font-semibold text-[#f5f3f0]">Destaques:</h4>
                        <div className="grid grid-cols-1 gap-2">
                            {activityHighlights.yoga.map((highlight, i) => (<div key={i} className="flex items-center space-x-2"><div className="w-2 h-2 bg-[#d4af37] rounded-full"></div><span className="text-[#7a9471] text-sm">{highlight}</span></div>))}
                        </div>
                    </div>
                    <div className="pt-4"><Button onClick={() => handleBookActivity("Yoga e Meditação")} className="w-full bg-[#d4af37] hover:bg-[#d4af37]/90 text-[#1a4d3a] font-semibold py-3 rounded-full">Reservar Atividade</Button></div>
                </div>
            </motion.div>

            {/* Observação de Aves */}
            <motion.div initial={{ opacity: 0, y: 50 }} whileInView={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 0.3 }} viewport={{ once: true }} className="glass-effect rounded-2xl overflow-hidden hover-lift group">
                <div className="relative h-64">
                    <img  alt="Observação de aves na floresta da Madeira" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" src="https://images.unsplash.com/photo-1695663159290-78a9e6bc66af" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                    <div className="absolute top-4 left-4 bg-[#d4af37]/90 rounded-full p-3"><div className="text-[#1a4d3a]"><Binoculars className="h-8 w-8" /></div></div>
                    <div className="absolute bottom-4 right-4 glass-effect rounded-xl p-3"><div className="flex items-center space-x-4 text-[#f5f3f0]"><div className="flex items-center space-x-1"><Clock className="h-4 w-4" /><span className="text-sm font-medium">3h</span></div><div className="flex items-center space-x-1"><Euro className="h-4 w-4" /><span className="text-sm font-medium">Gratuita</span></div></div></div>
                </div>
                <div className="p-8 space-y-6">
                    <div>
                        <h3 className="font-display text-2xl font-bold text-[#f5f3f0] mb-3">Observação de Aves</h3>
                        <p className="text-[#7a9471] leading-relaxed">Explore a rica avifauna da Madeira com binóculos profissionais. Descubra espécies endémicas e migratórias num ambiente natural preservado.</p>
                    </div>
                    <div className="space-y-3">
                        <h4 className="font-semibold text-[#f5f3f0]">Destaques:</h4>
                        <div className="grid grid-cols-1 gap-2">
                            {activityHighlights.aves.map((highlight, i) => (<div key={i} className="flex items-center space-x-2"><div className="w-2 h-2 bg-[#d4af37] rounded-full"></div><span className="text-[#7a9471] text-sm">{highlight}</span></div>))}
                        </div>
                    </div>
                    <div className="pt-4"><Button onClick={() => handleBookActivity("Observação de Aves")} className="w-full bg-[#d4af37] hover:bg-[#d4af37]/90 text-[#1a4d3a] font-semibold py-3 rounded-full">Participar</Button></div>
                </div>
            </motion.div>

            {/* Caminhadas Noturnas */}
            <motion.div initial={{ opacity: 0, y: 50 }} whileInView={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 0.4 }} viewport={{ once: true }} className="glass-effect rounded-2xl overflow-hidden hover-lift group">
                <div className="relative h-64">
                    <img  alt="Caminhada noturna mágica na floresta" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" src="https://images.unsplash.com/photo-1702957635861-5c9cfcea0b55" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                    <div className="absolute top-4 left-4 bg-[#d4af37]/90 rounded-full p-3"><div className="text-[#1a4d3a]"><Moon className="h-8 w-8" /></div></div>
                    <div className="absolute bottom-4 right-4 glass-effect rounded-xl p-3"><div className="flex items-center space-x-4 text-[#f5f3f0]"><div className="flex items-center space-x-1"><Clock className="h-4 w-4" /><span className="text-sm font-medium">2h</span></div><div className="flex items-center space-x-1"><Euro className="h-4 w-4" /><span className="text-sm font-medium">Gratuita</span></div></div></div>
                </div>
                <div className="p-8 space-y-6">
                    <div>
                        <h3 className="font-display text-2xl font-bold text-[#f5f3f0] mb-3">Caminhadas Noturnas</h3>
                        <p className="text-[#7a9471] leading-relaxed">Experimente a magia da floresta ao anoitecer. Descubra os sons noturnos, observe as estrelas e sinta a energia única da natureza durante a noite.</p>
                    </div>
                    <div className="space-y-3">
                        <h4 className="font-semibold text-[#f5f3f0]">Destaques:</h4>
                        <div className="grid grid-cols-1 gap-2">
                            {activityHighlights.noturnas.map((highlight, i) => (<div key={i} className="flex items-center space-x-2"><div className="w-2 h-2 bg-[#d4af37] rounded-full"></div><span className="text-[#7a9471] text-sm">{highlight}</span></div>))}
                        </div>
                    </div>
                    <div className="pt-4"><Button onClick={() => handleBookActivity("Caminhadas Noturnas")} className="w-full bg-[#d4af37] hover:bg-[#d4af37]/90 text-[#1a4d3a] font-semibold py-3 rounded-full">Participar</Button></div>
                </div>
            </motion.div>

            {/* Piqueniques na Floresta */}
            <motion.div initial={{ opacity: 0, y: 50 }} whileInView={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 0.5 }} viewport={{ once: true }} className="glass-effect rounded-2xl overflow-hidden hover-lift group">
                <div className="relative h-64">
                    <img  alt="Piquenique romântico na floresta" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" src="https://images.unsplash.com/photo-1675597301162-f41d030cb205" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                    <div className="absolute top-4 left-4 bg-[#d4af37]/90 rounded-full p-3"><div className="text-[#1a4d3a]"><Users className="h-8 w-8" /></div></div>
                    <div className="absolute bottom-4 right-4 glass-effect rounded-xl p-3"><div className="flex items-center space-x-4 text-[#f5f3f0]"><div className="flex items-center space-x-1"><Clock className="h-4 w-4" /><span className="text-sm font-medium">Flexível</span></div><div className="flex items-center space-x-1"><Euro className="h-4 w-4" /><span className="text-sm font-medium">Sob consulta</span></div></div></div>
                </div>
                <div className="p-8 space-y-6">
                    <div>
                        <h3 className="font-display text-2xl font-bold text-[#f5f3f0] mb-3">Piqueniques na Floresta</h3>
                        <p className="text-[#7a9471] leading-relaxed">Desfrute de refeições especiais em locais únicos da floresta. Produtos locais e biológicos numa experiência gastronómica em plena natureza.</p>
                    </div>
                    <div className="space-y-3">
                        <h4 className="font-semibold text-[#f5f3f0]">Destaques:</h4>
                        <div className="grid grid-cols-1 gap-2">
                            {activityHighlights.piqueniques.map((highlight, i) => (<div key={i} className="flex items-center space-x-2"><div className="w-2 h-2 bg-[#d4af37] rounded-full"></div><span className="text-[#7a9471] text-sm">{highlight}</span></div>))}
                        </div>
                    </div>
                    <div className="pt-4"><Button onClick={() => handleBookActivity("Piqueniques na Floresta")} className="w-full bg-[#d4af37] hover:bg-[#d4af37]/90 text-[#1a4d3a] font-semibold py-3 rounded-full">Reservar Atividade</Button></div>
                </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Info Section */}
      <section className="section-padding bg-black/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <h2 className="font-display text-4xl md:text-5xl font-bold text-[#f5f3f0] mb-6">
                Experiências <span className="text-[#d4af37]">Autênticas</span>
              </h2>
              <div className="space-y-6 text-[#7a9471] text-lg leading-relaxed">
                <p>
                  Todas as nossas atividades são cuidadosamente planeadas para proporcionar 
                  uma conexão autêntica com a natureza, respeitando o ambiente e promovendo 
                  a sustentabilidade.
                </p>
                <p>
                  Os nossos guias especializados partilham conhecimentos profundos sobre a 
                  flora, fauna e história da floresta Laurissilva, tornando cada experiência 
                  educativa e memorável.
                </p>
                <p>
                  Seja para relaxar, aprender ou aventurar-se, temos a atividade perfeita 
                  para tornar a sua estadia inesquecível.
                </p>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="relative"
            >
              <div className="relative rounded-2xl overflow-hidden hover-lift">
                <img  alt="Guia especializado explicando sobre a flora da floresta Laurissilva" className="w-full h-96 object-cover" src="https://images.unsplash.com/photo-1687231446267-0d04cef2fbfe" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent"></div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section-padding">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="glass-effect rounded-3xl p-12 hover-lift"
          >
            <h2 className="font-display text-4xl md:text-5xl font-bold text-[#f5f3f0] mb-6">
              Pronto para a <span className="text-[#d4af37]">Aventura?</span>
            </h2>
            <p className="text-xl text-[#7a9471] mb-8 max-w-2xl mx-auto">
              Contacte-nos para mais informações sobre as nossas atividades e para 
              personalizar a sua experiência na floresta Laurissilva.
            </p>
            
            <Button 
              onClick={() => handleBookActivity("qualquer atividade")}
              className="bg-[#d4af37] hover:bg-[#d4af37]/90 text-[#1a4d3a] font-semibold px-8 py-4 text-lg rounded-full hover-lift"
            >
              Contactar para Informações
            </Button>
          </motion.div>
        </div>
      </section>
    </>
  );
};

export default Activities;