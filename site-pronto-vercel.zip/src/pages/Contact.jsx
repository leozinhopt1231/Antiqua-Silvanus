import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { Mail, Phone, Instagram, MapPin, Clock, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: ''
  });

  const contactInfo = [
    {
      icon: <Mail className="h-6 w-6" />,
      label: "Email",
      value: "info@antiquasilvanus.pt",
      link: "mailto:info@antiquasilvanus.pt"
    },
    {
      icon: <Phone className="h-6 w-6" />,
      label: "Telefone",
      value: "+351 912 345 678",
      link: "tel:+351912345678"
    },
    {
      icon: <Instagram className="h-6 w-6" />,
      label: "Instagram",
      value: "@antiquasilvanus",
      link: "https://instagram.com/antiquasilvanus"
    },
    {
      icon: <MapPin className="h-6 w-6" />,
      label: "Localização",
      value: "Vereda da Floresta 42, Porto Moniz, Madeira",
      link: "#"
    }
  ];

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    toast({
      title: "📧 Mensagem Enviada!",
      description: "🚧 A funcionalidade de envio de mensagens ainda não está implementada—mas não se preocupe! Pode solicitar esta funcionalidade no seu próximo prompt! 🚀",
      duration: 5000,
    });
    
    // Reset form
    setFormData({
      name: '',
      email: '',
      phone: '',
      subject: '',
      message: ''
    });
  };

  return (
    <>
      <Helmet>
        <title>Contactos - Antiqua Silvanus Eco Lodge</title>
        <meta name="description" content="Entre em contacto connosco. Email: info@antiquasilvanus.pt, Telefone: +351 912 345 678, Instagram: @antiquasilvanus. Localização: Vereda da Floresta 42, Porto Moniz, Madeira." />
      </Helmet>

      {/* Hero Section */}
      <section className="relative min-h-[60vh] flex items-center justify-center overflow-hidden mt-20">
        <div className="absolute inset-0 z-0">
          <img  alt="Vista da localização do Antiqua Silvanus na floresta Laurissilva" className="w-full h-full object-cover" src="https://images.unsplash.com/photo-1629642974896-9be4337f8f9f" />
          <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/30 to-black/60"></div>
        </div>

        <div className="relative z-10 text-center px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1 }}
            className="space-y-6"
          >
            <h1 className="font-display text-5xl md:text-6xl font-bold text-[#f5f3f0] text-shadow">
              Entre em <span className="text-[#d4af37]">Contacto</span>
            </h1>
            <p className="text-xl md:text-2xl text-[#7a9471] max-w-3xl mx-auto">
              Estamos aqui para tornar a sua experiência na floresta Laurissilva inesquecível
            </p>
          </motion.div>
        </div>
      </section>

      {/* Contact Info & Form */}
      <section className="section-padding">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Information */}
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="space-y-8"
            >
              <div>
                <h2 className="font-display text-4xl md:text-5xl font-bold text-[#f5f3f0] mb-6">
                  Fale <span className="text-[#d4af37]">Connosco</span>
                </h2>
                <p className="text-lg text-[#7a9471] leading-relaxed">
                  A nossa equipa está sempre disponível para esclarecer dúvidas, 
                  ajudar com reservas ou fornecer informações sobre as nossas 
                  experiências únicas na floresta Laurissilva.
                </p>
              </div>

              <div className="space-y-6">
                {contactInfo.map((info, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 30 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6, delay: index * 0.1 }}
                    viewport={{ once: true }}
                    className="glass-effect rounded-xl p-6 hover-lift group"
                  >
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-[#d4af37]/20 rounded-full flex items-center justify-center group-hover:bg-[#d4af37]/30 transition-colors duration-300">
                        <div className="text-[#d4af37]">
                          {info.icon}
                        </div>
                      </div>
                      <div>
                        <div className="text-[#f5f3f0] font-semibold mb-1">
                          {info.label}
                        </div>
                        <a 
                          href={info.link}
                          className="text-[#7a9471] hover:text-[#d4af37] transition-colors duration-300"
                        >
                          {info.value}
                        </a>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>

              <div className="glass-effect rounded-xl p-6">
                <div className="flex items-center space-x-4 mb-4">
                  <div className="w-12 h-12 bg-[#d4af37]/20 rounded-full flex items-center justify-center">
                    <Clock className="h-6 w-6 text-[#d4af37]" />
                  </div>
                  <div>
                    <div className="text-[#f5f3f0] font-semibold">Horário de Atendimento</div>
                  </div>
                </div>
                <div className="space-y-2 text-[#7a9471] ml-16">
                  <div className="flex justify-between">
                    <span>Segunda a Domingo:</span>
                    <span>08h00 - 22h00</span>
                  </div>
                  <div className="text-sm text-[#7a9471]/80">
                    Recepção disponível 24 horas para hóspedes
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Contact Form */}
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="glass-effect rounded-2xl p-8"
            >
              <h3 className="font-display text-3xl font-bold text-[#f5f3f0] mb-6">
                Envie-nos uma Mensagem
              </h3>
              
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="name" className="block text-[#f5f3f0] font-medium mb-2">
                      Nome *
                    </label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      required
                      className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-[#f5f3f0] placeholder-[#7a9471] focus:outline-none focus:ring-2 focus:ring-[#d4af37] focus:border-transparent"
                      placeholder="O seu nome"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="email" className="block text-[#f5f3f0] font-medium mb-2">
                      Email *
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      required
                      className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-[#f5f3f0] placeholder-[#7a9471] focus:outline-none focus:ring-2 focus:ring-[#d4af37] focus:border-transparent"
                      placeholder="o.seu.email@exemplo.com"
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="phone" className="block text-[#f5f3f0] font-medium mb-2">
                    Telefone
                  </label>
                  <input
                    type="tel"
                    id="phone"
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-[#f5f3f0] placeholder-[#7a9471] focus:outline-none focus:ring-2 focus:ring-[#d4af37] focus:border-transparent"
                    placeholder="+351 912 345 678"
                  />
                </div>

                <div>
                  <label htmlFor="subject" className="block text-[#f5f3f0] font-medium mb-2">
                    Assunto *
                  </label>
                  <select
                    id="subject"
                    name="subject"
                    value={formData.subject}
                    onChange={handleInputChange}
                    required
                    className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-[#f5f3f0] focus:outline-none focus:ring-2 focus:ring-[#d4af37] focus:border-transparent"
                  >
                    <option value="">Selecione um assunto</option>
                    <option value="reserva">Reserva de Alojamento</option>
                    <option value="atividades">Informações sobre Atividades</option>
                    <option value="workshops">Workshops e Experiências</option>
                    <option value="restaurante">Restaurante e Bar</option>
                    <option value="inauguracao">Evento de Inauguração</option>
                    <option value="geral">Informação Geral</option>
                  </select>
                </div>

                <div>
                  <label htmlFor="message" className="block text-[#f5f3f0] font-medium mb-2">
                    Mensagem *
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleInputChange}
                    required
                    rows={5}
                    className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-[#f5f3f0] placeholder-[#7a9471] focus:outline-none focus:ring-2 focus:ring-[#d4af37] focus:border-transparent resize-vertical"
                    placeholder="Escreva aqui a sua mensagem..."
                  />
                </div>

                <Button 
                  type="submit"
                  className="w-full bg-[#d4af37] hover:bg-[#d4af37]/90 text-[#1a4d3a] font-semibold py-4 rounded-full hover-lift"
                >
                  <Send className="mr-2 h-5 w-5" />
                  Enviar Mensagem
                </Button>
              </form>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Location Section */}
      <section className="section-padding bg-black/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="font-display text-4xl md:text-5xl font-bold text-[#f5f3f0] mb-6">
              Nossa <span className="text-[#d4af37]">Localização</span>
            </h2>
            <p className="text-xl text-[#7a9471] max-w-3xl mx-auto">
              Encontre-nos no coração da floresta Laurissilva, em Porto Moniz
            </p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <div className="glass-effect rounded-2xl p-8">
                <h3 className="font-display text-2xl font-bold text-[#f5f3f0] mb-6">
                  Como Chegar
                </h3>
                <div className="space-y-4 text-[#7a9471]">
                  <div className="flex items-start space-x-3">
                    <MapPin className="h-5 w-5 text-[#d4af37] mt-1 flex-shrink-0" />
                    <div>
                      <div className="font-semibold text-[#f5f3f0]">Morada Completa:</div>
                      <div>Vereda da Floresta 42</div>
                      <div>9270-156 Porto Moniz</div>
                      <div>Madeira, Portugal</div>
                    </div>
                  </div>
                  
                  <div className="border-t border-white/10 pt-4">
                    <div className="font-semibold text-[#f5f3f0] mb-2">Direções:</div>
                    <ul className="space-y-2 text-sm">
                      <li>• Do Funchal: 1h30 via ER101 e ER110</li>
                      <li>• Do Porto Santo: Ferry + 1h30 de carro</li>
                      <li>• Do Aeroporto: 1h45 via VR1 e ER101</li>
                      <li>• Coordenadas GPS: 32.8647°N, 17.1364°W</li>
                    </ul>
                  </div>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="relative"
            >
              <div className="relative rounded-2xl overflow-hidden hover-lift">
                <img  alt="Mapa da localização do Antiqua Silvanus em Porto Moniz" className="w-full h-96 object-cover" src="https://images.unsplash.com/photo-1538514860079-8443cff3cb21" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent"></div>
                
                <div className="absolute bottom-6 left-6 glass-effect rounded-xl p-4">
                  <div className="text-[#f5f3f0] font-semibold">Antiqua Silvanus</div>
                  <div className="text-[#7a9471] text-sm">Porto Moniz, Madeira</div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section-padding">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="glass-effect rounded-3xl p-12 hover-lift"
          >
            <h2 className="font-display text-4xl md:text-5xl font-bold text-[#f5f3f0] mb-6">
              Pronto para a <span className="text-[#d4af37]">Aventura?</span>
            </h2>
            <p className="text-xl text-[#7a9471] mb-8 max-w-2xl mx-auto">
              Entre em contacto connosco hoje mesmo e comece a planear a sua 
              experiência única na floresta Laurissilva da Madeira.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a href="mailto:info@antiquasilvanus.pt">
                <Button className="bg-[#d4af37] hover:bg-[#d4af37]/90 text-[#1a4d3a] font-semibold px-8 py-4 text-lg rounded-full hover-lift">
                  Enviar Email
                </Button>
              </a>
              
              <a href="tel:+351912345678">
                <Button variant="outline" className="border-[#f5f3f0] text-[#f5f3f0] hover:bg-[#f5f3f0] hover:text-[#1a4d3a] px-8 py-4 text-lg rounded-full hover-lift">
                  Ligar Agora
                </Button>
              </a>
            </div>
          </motion.div>
        </div>
      </section>
    </>
  );
};

export default Contact;